package InterfaceFraficaAlgoritimo;

public class BaseDonn�es {
    public BaseDonn�es() {
        super();
    }
}

