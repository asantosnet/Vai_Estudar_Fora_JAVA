Ce fichier contient le file jpr, donc vous pouvez importe le projet directment.
Pour l'acceder aller en PorjetoVaiEstudarFora et apr�es VaiEstudarFora
Si vous avez des erreurs au moment qui vous l'importe, ces � 
cause des blibioteques.Utilise celle que sont dans le fichier Jar nescessaire
+ telecharge le word wind

Pour faire compiler cette applicatin il faut que le world wind nasa 
soit telecharche

http://worldwind.arc.nasa.gov/java/ et la version est la 1.51
http://ifgi.uni-muenster.de/worldwind-tutorial/?page_id=7

Il faut aussi que vous atendiez environ 1min � cause des marker que s'affichent
sur le globe

Il faut avoir tous les jars qui j'ai mis plus
		JDeveloper Runtime
		JGodies Forms

Le jar du WolrdWind sont
	Gluegen_rt.jar
	WolrdWind.jar
	WolrdWindx.jar
	Jogl.jar
	Gdal.jar
Il faut quand meme telecharger le wolrd wind